﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelipePrueba.DataAccess
{
    public class Command
    {
        private readonly DbConnection _dbConnection;
        private readonly SqlCommand _command;
        private SqlDataReader? _reader;

        public Command()
        {
            _dbConnection = new DbConnection();
            _command = new SqlCommand();
        }

        public void InitCommand(string query)
        {
            try
            {
                _dbConnection.OpenConnection();
                _command.Connection = _dbConnection.GetConnection();
                _command.CommandText = query;
            }
            catch
            {
                throw;
            }
        }

        public SqlDataReader ReadData()
        {
            try
            {
                _reader = _command.ExecuteReader();
                return _reader;
            }
            catch
            {
                throw;
            }
        }

        public void SetCommandParam(string parameter, object value)
        {
            try
            {
                _command.Parameters.AddWithValue(parameter, value);  
            }
            catch
            {
                throw;
            }
        }

        public void ClearCommandParams()
        {
            try
            {
                _command.Parameters.Clear();
            }
            catch
            {
                throw;
            }
        }

        public void ExecuteQuery()
        {
            try
            {
                _command.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }
        }

        public void DisposeAll()
        {
            _command.Dispose();
            _reader?.Close();
            _dbConnection.CloseConnection();
        }
    }
}
