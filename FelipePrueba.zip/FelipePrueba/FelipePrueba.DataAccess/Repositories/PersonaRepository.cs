﻿using FelipePrueba.DataAccess.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelipePrueba.DataAccess.Repositories
{
    public class PersonaRepository
    {
        private readonly Command _command;

        public PersonaRepository()
        {
            _command = new Command();
        }

        public List<Persona> GetPersonas()
        {
            try
            {
                var personas = new List<Persona>();

                _command.SetCommandParam("@Estado", true);
                _command.InitCommand("SELECT ID, Nombre, FechaNacimiento, Estado FROM Personas WHERE Estado = @Estado");
                var reader = _command.ReadData();


                while (reader.Read())
                {
                    var persona = new Persona()
                    {
                        ID = reader.GetInt32(0),
                        Nombre = reader.GetString(1),
                        FechaNacimiento = reader.GetDateTime(2),
                        Estado = reader.GetBoolean(3)
                    };

                    personas.Add(persona);  
                }
                _command.ClearCommandParams();

                return personas;
            }
            catch
            {
                throw;
            }
            finally
            {
                _command.DisposeAll();
            }
        }

        public void AddPersona(Persona persona)
        {
            try
            {
                var parameters = SetPersonaParameters(persona);

                string query = $"INSERT INTO Personas(Nombre, FechaNacimiento) VALUES(@Nombre, @FechaNacimiento)";
                _command.InitCommand(query);

                foreach (var key in parameters.Keys)
                    _command.SetCommandParam(key, parameters[key]);

                _command.ExecuteQuery();
                _command.ClearCommandParams();

            }
            catch
            {
                throw;
            }
            finally
            {
                _command.DisposeAll();
            }
        }

        public void UpdatePersona(Persona persona)
        {
            try
            {
                var parameters = SetPersonaParameters(persona);
                parameters.Add("@ID", persona.ID);

                string query = "UPDATE Personas SET Nombre = @Nombre, FechaNacimiento = @FechaNacimiento WHERE ID = @ID";
                _command.InitCommand(query);

                foreach (var key in parameters.Keys)
                    _command.SetCommandParam(key, parameters[key]);

                _command.ExecuteQuery();
                _command.ClearCommandParams();
            }
            catch
            {
                throw;
            }
            finally
            {
                _command.DisposeAll();
            }
        }

        public void DeletePersona(int idPersona)
        {
            try
            {
                string query = "UPDATE Personas SET Estado = @Estado WHERE ID = @ID";
                _command.InitCommand(query);

                _command.SetCommandParam("@Estado", 0);
                _command.SetCommandParam("@ID", idPersona);

                _command.ExecuteQuery();
                _command.ClearCommandParams();
            }
            catch
            {
                throw;
            }
            finally
            {
                _command.DisposeAll();
            }
        }

        private Dictionary<string, object> SetPersonaParameters(Persona persona)
        {
            var parameters = new Dictionary<string, object>();
            parameters.Add("@Nombre", persona.Nombre ?? "");
            parameters.Add("@FechaNacimiento", persona.FechaNacimiento);
            return parameters;
        }
    }
}
