using FelipePrueba.Core.Services;
using FelipePrueba.DataAccess.Entities;

namespace FelipePrueba
{
    public partial class Form1 : Form
    {
        private readonly PersonaService? _personaService;
        public Form1()
        {
            InitializeComponent();
            _personaService = new PersonaService();
            try
            {
                dgvPersonas.DataSource = _personaService.GetPersonas();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtNombre.Text))
                    MessageBox.Show("Debes escribir el nombre de la persona");
                else
                {
                    var persona = new Persona()
                    {
                        Nombre = txtNombre.Text,
                        FechaNacimiento = dtNacimiento.Value
                    };
                    _personaService?.AddPersona(persona);
                    RefreshDataGrid();
                    ClearFields();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtNombre.Text))
                    MessageBox.Show("Debes escribir el nombre de la persona");
                else
                {
                    int.TryParse(txtID.Text, out int idPersona);
                    var persona = new Persona()
                    {
                        ID = idPersona,
                        Nombre = txtNombre.Text,
                        FechaNacimiento = dtNacimiento.Value
                    };
                    _personaService?.UpdatePersona(persona);
                    RefreshDataGrid();
                    ClearFields();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvPersonas.SelectedRows.Count > 0)
                {
                    var personas = _personaService?.GetPersonas() ?? new List<Persona>();
                    var result = MessageBox.Show("�Est�s seguro de querer eliminar a esta(s) persona?", "Confirmar", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        foreach(var row in dgvPersonas.SelectedRows)
                        {
                            var rowObject = (DataGridViewBand)row;
                            _personaService?.DeletePersona(personas[rowObject.Index].ID);
                        }
                        RefreshDataGrid();
                    }
                }
                else
                    MessageBox.Show("No has seleccionado ninguna fila(s)");
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void RefreshDataGrid()
        {
            dgvPersonas.DataSource = null;
            dgvPersonas.DataSource = _personaService?.GetPersonas();
            FormatDataGrid();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FormatDataGrid();
        }
        private void FormatDataGrid()
        {
            dgvPersonas.Columns[2].HeaderText = "Fecha de Nacimiento";
            dgvPersonas.ClearSelection();
        }

        private void dgvPersonas_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            var personas = _personaService?.GetPersonas();
            var persona = personas?[e.RowIndex];

            if(persona != null)
            {
                txtID.Text = persona.ID.ToString();
                txtNombre.Text = persona.Nombre;
                dtNacimiento.Value = persona.FechaNacimiento;
            }
        }

        private void cleanBtn_Click(object sender, EventArgs e)
        {
            ClearFields();
        }
        private void ClearFields()
        {
            txtNombre.Text = string.Empty;
            dtNacimiento.Text = string.Empty;
            txtID.Text = string.Empty;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}