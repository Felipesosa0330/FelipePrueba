﻿using FelipePrueba.DataAccess.Entities;
using FelipePrueba.DataAccess.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelipePrueba.Core.Services
{
    public class PersonaService
    {
        private readonly PersonaRepository _personaRepository;

        public PersonaService()
        {
            _personaRepository = new PersonaRepository();
        }

        public List<Persona> GetPersonas()
        {
            try
            {
                return _personaRepository.GetPersonas();
            }
            catch
            {
                throw;
            }
        }

        public void AddPersona(Persona persona)
        {
            try
            {
                _personaRepository.AddPersona(persona);
            }
            catch
            {
                throw;
            }
        }

        public void UpdatePersona(Persona persona)
        {
            try
            {
                _personaRepository.UpdatePersona(persona);  
            }
            catch
            {
                throw;
            }
        }

        public void DeletePersona(int idPersona)
        {
            try
            {
                _personaRepository.DeletePersona(idPersona);
            }
            catch
            {
                throw;
            }
        }
    }
}
