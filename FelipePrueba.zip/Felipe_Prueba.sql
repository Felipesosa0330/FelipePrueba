CREATE DATABASE Felipe_PruebaDb
GO

USE Felipe_PruebaDb
GO

CREATE TABLE Personas (
	ID INT NOT NULL IDENTITY(1,1),
	Nombre VARCHAR(50) NOT NULL,
	FechaNacimiento DATE NOT NULL,
	Estado BIT NOT NULL DEFAULT(1),

	CONSTRAINT Pk_Personas PRIMARY KEY(ID)
)
GO

SELECT * FROM Personas 